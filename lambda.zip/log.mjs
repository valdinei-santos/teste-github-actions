export function log(mensagem) {
    console.log('log via função', mensagem);
}